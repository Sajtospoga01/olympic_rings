# CSS-Only Olympic Rings

A Pen created on CodePen.io. Original URL: [https://codepen.io/Sajtospoga01/pen/zYJvRya](https://codepen.io/Sajtospoga01/pen/zYJvRya).

Olympic rings logo in CSS.